/**
 * 
 */
/**
 * 
 */
module Ejer_herencia4 {
}